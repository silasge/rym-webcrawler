__version__ = '0.2.0'

from rym_webcrawler.rym import RymCharts